"use strict";
(() => {
  // extension/background.ts
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
      console.log("JobFlow Autofill installed");
      chrome.tabs.create({
        url: chrome.runtime.getURL("popup.html?onboarding=true")
      });
    } else if (details.reason === "update") {
      console.log("JobFlow Autofill updated to version", chrome.runtime.getManifest().version);
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch((error) => {
      console.error("Message handler error:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  });
  async function handleMessage(message, _sender) {
    switch (message.type) {
      case "GET_PROFILE":
        return getProfile();
      case "SAVE_PROFILE":
        return saveProfile(message.payload);
      case "AUTOFILL":
        return autofillWithUsageCheck(message.payload, _sender);
      case "TRACK_FILL":
        return trackFill(message.payload);
      case "DETECT_FORM":
        return { success: true, data: { detected: true } };
      case "SAVE_FORM_SCHEMA":
        return saveFormSchema(message.payload);
      case "GET_FORM_SCHEMAS":
        return getFormSchemas(message.payload);
      case "LOG_APPLICATION":
        return logApplication(message.payload);
      case "SHOW_NOTIFICATION":
        return showNotification(message.payload);
      case "GET_FILL_COUNT":
        return getFillCount();
      case "CONTENT_SCRIPT_READY":
      case "FORM_DETECTED":
        return { success: true };
      default:
        return { success: false, error: `Unknown message type: ${message.type}` };
    }
  }
  async function getProfile() {
    try {
      const result = await chrome.storage.local.get("profile");
      if (result.profile) {
        return { success: true, data: result.profile };
      }
      return {
        success: true,
        data: {
          personal: {
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            location: {
              address: "",
              city: "",
              state: "",
              zip: "",
              country: ""
            }
          },
          workExperience: [],
          education: [],
          skills: [],
          answers: []
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to get profile"
      };
    }
  }
  async function saveProfile(profile) {
    try {
      await chrome.storage.local.set({ profile });
      broadcastToWebApp({ type: "PROFILE_UPDATED", payload: profile });
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to save profile"
      };
    }
  }
  var FREE_FILL_LIMIT = 10;
  function getCurrentMonth() {
    const now = /* @__PURE__ */ new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }
  async function getUsageData() {
    const result = await chrome.storage.local.get("usageData");
    const month = getCurrentMonth();
    if (result.usageData && result.usageData.month === month) {
      return result.usageData;
    }
    const data = { month, fillCount: 0, plan: result.usageData?.plan || "free" };
    await chrome.storage.local.set({ usageData: data });
    return data;
  }
  async function incrementUsageCount() {
    const data = await getUsageData();
    data.fillCount++;
    await chrome.storage.local.set({ usageData: data });
  }
  async function autofillWithUsageCheck(payload, sender) {
    const usage = await getUsageData();
    if (usage.plan === "free" && usage.fillCount >= FREE_FILL_LIMIT) {
      if (sender.tab?.id) {
        chrome.tabs.sendMessage(sender.tab.id, {
          type: "SHOW_UPGRADE_PROMPT",
          payload: {
            fillCount: usage.fillCount,
            limit: FREE_FILL_LIMIT
          }
        }).catch(() => {
        });
      }
      return {
        success: false,
        error: `Free plan limit reached (${FREE_FILL_LIMIT} fills/month). Upgrade to Pro for unlimited fills.`
      };
    }
    const result = await autofill(payload);
    if (result.success && result.filledCount && result.filledCount > 0) {
      await incrementUsageCount();
    }
    return result;
  }
  async function autofill(payload) {
    try {
      const profileResult = await getProfile();
      if (!profileResult.success || !profileResult.data) {
        return { success: false, error: "No profile found" };
      }
      const profile = profileResult.data;
      let filledCount = 0;
      for (const field of payload.fields) {
        if (field.suggestedMapping) {
          const value = getNestedValue(profile, field.suggestedMapping);
          if (value !== null && value !== void 0) {
            filledCount++;
          }
        }
      }
      return { success: true, filledCount };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Autofill failed"
      };
    }
  }
  function getNestedValue(obj, path) {
    return path.split(".").reduce((current, key) => {
      return current && typeof current === "object" && key in current ? current[key] : null;
    }, obj);
  }
  function getUsageKey() {
    const now = /* @__PURE__ */ new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    return `usage_${year}_${month}`;
  }
  async function trackFill(payload) {
    try {
      const key = getUsageKey();
      const result = await chrome.storage.local.get(key);
      const current = result[key] || 0;
      const total = current + payload.count;
      await chrome.storage.local.set({ [key]: total });
      chrome.action.setBadgeText({ text: String(total) });
      chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
      return { success: true, data: { total } };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to track fill"
      };
    }
  }
  async function getFillCount() {
    try {
      const key = getUsageKey();
      const result = await chrome.storage.local.get(key);
      const count = result[key] || 0;
      return { success: true, data: { count } };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to get fill count"
      };
    }
  }
  (async () => {
    const key = getUsageKey();
    const result = await chrome.storage.local.get(key);
    const count = result[key] || 0;
    if (count > 0) {
      chrome.action.setBadgeText({ text: String(count) });
      chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
    }
  })();
  async function saveFormSchema(schema) {
    try {
      const result = await chrome.storage.local.get("formSchemas");
      const schemas = result.formSchemas || [];
      const existingIndex = schemas.findIndex(
        (s) => s.domain === schema.domain && s.urlPattern === schema.urlPattern
      );
      if (existingIndex >= 0) {
        schemas[existingIndex] = schema;
      } else {
        schemas.push(schema);
      }
      await chrome.storage.local.set({ formSchemas: schemas });
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to save schema"
      };
    }
  }
  async function getFormSchemas(payload) {
    try {
      const result = await chrome.storage.local.get("formSchemas");
      const schemas = result.formSchemas || [];
      const filtered = schemas.filter((s) => s.domain === payload.domain);
      return { success: true, data: filtered };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to get schemas"
      };
    }
  }
  async function logApplication(payload) {
    try {
      const result = await chrome.storage.local.get("applications");
      const applications = result.applications || [];
      const newApplication = {
        id: crypto.randomUUID(),
        company: payload.company,
        position: payload.position,
        sourceUrl: payload.sourceUrl,
        appliedDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
        status: "active",
        stage: "applied",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      applications.unshift(newApplication);
      await chrome.storage.local.set({ applications });
      showNotification({
        title: "Application Logged",
        message: `${payload.company} - ${payload.position}`
      });
      return { success: true, data: newApplication };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to log application"
      };
    }
  }
  async function showNotification(payload) {
    try {
      await chrome.notifications.create({
        type: payload.type || "basic",
        iconUrl: "icons/icon128.png",
        title: payload.title,
        message: payload.message
      });
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to show notification"
      };
    }
  }
  var JOB_SITE_PATTERNS = [
    "greenhouse.io",
    "lever.co",
    "workday.com",
    "myworkdayjobs.com",
    "indeed.com",
    "linkedin.com/jobs",
    "glassdoor.com",
    "monster.com",
    "ziprecruiter.com",
    "smartrecruiters.com",
    "jobvite.com",
    "icims.com",
    "taleo.net",
    "brassring.com",
    "careers",
    "/apply",
    "/application"
  ];
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
      try {
        const url = new URL(tab.url);
        const isJobSite = JOB_SITE_PATTERNS.some(
          (pattern) => url.hostname.includes(pattern) || url.pathname.includes(pattern)
        );
        if (isJobSite) {
          chrome.action.setBadgeText({ text: "!", tabId });
          chrome.action.setBadgeBackgroundColor({ color: "#10B981", tabId });
        }
      } catch {
      }
    }
  });
  chrome.runtime.onMessageExternal?.addListener((message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch((error) => {
      sendResponse({ success: false, error: error.message });
    });
    return true;
  });
  function broadcastToWebApp(message) {
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (tab.id && tab.url) {
          chrome.tabs.sendMessage(tab.id, {
            type: "WEBAPP_BROADCAST",
            payload: message
          }).catch(() => {
          });
        }
      }
    });
  }
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.profile) {
      broadcastToWebApp({
        type: "PROFILE_UPDATED",
        payload: changes.profile.newValue
      });
    }
  });
  console.log("JobFlow Autofill: Background service worker initialized");
})();
